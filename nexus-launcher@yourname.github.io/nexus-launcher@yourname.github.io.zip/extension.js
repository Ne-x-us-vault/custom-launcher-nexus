import Shell from 'gi://Shell';
import Meta from 'gi://Meta';
import Gtk from 'gi://Gtk';
import Gdk from 'gi://Gdk';
import GLib from 'gi://GLib';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import Overlay from './lib/overlay.js';

export default class NexusLauncherExtension extends Extension {
  constructor(metadata) {
    super(metadata);
    this._settings = null;
    this._overlay = null;
    this._cssProvider = null;
    this._keybinding = 'hotkey';
  }

  enable() {
    this._settings = this.getSettings();
    this._loadStylesheet();
    this._overlay = new Overlay(this._settings);
    this._registerKeybinding();
  }

  disable() {
    this._destroyOverlay();
    this._unregisterKeybinding();
    this._unloadStylesheet();
    this._settings = null;
  }

  _loadStylesheet() {
    if (this._cssProvider) {
      return;
    }

    this._cssProvider = new Gtk.CssProvider();
    const stylesheetPath = GLib.build_filenamev([this.path, 'stylesheet.css']);
    this._cssProvider.load_from_path(stylesheetPath);
    Gtk.StyleContext.add_provider_for_display(
      Gdk.Display.get_default(),
      this._cssProvider,
      Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
    );
  }

  _unloadStylesheet() {
    if (!this._cssProvider) {
      return;
    }

    Gtk.StyleContext.remove_provider_for_display(
      Gdk.Display.get_default(),
      this._cssProvider
    );
    this._cssProvider = null;
  }

  _registerKeybinding() {
    if (!Main.wm || !Main.wm.addKeybinding) {
      return;
    }

    Main.wm.addKeybinding(
      this._keybinding,
      this._settings,
      Meta.KeyBindingFlags.NONE,
      Shell.ActionMode.ALL,
      () => this._toggleOverlay()
    );
  }

  _unregisterKeybinding() {
    if (!Main.wm || !Main.wm.removeKeybinding) {
      return;
    }

    Main.wm.removeKeybinding(this._keybinding);
  }

  _toggleOverlay() {
    if (!this._overlay) {
      return;
    }

    if (this._overlay.visible) {
      this._overlay.close();
    } else {
      this._overlay.open();
    }
  }

  _destroyOverlay() {
    if (!this._overlay) {
      return;
    }

    this._overlay.destroy();
    this._overlay = null;
  }
}
